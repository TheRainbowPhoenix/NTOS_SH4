﻿var sRealPageUrl = realPageURL();
var sMainTitle = L_TopFrameUnsafe_TEXT;
var sOriginalSite = "";
var sContentLocations = contentLocations();

function realPageURL() {
    "use strict";
    var urlresult = '';
    var DocURL = document.location.href;

    var BeginURL = DocURL.indexOf("#", 1) + 1;
    urlresult = DocURL.substring(BeginURL);

    if (!isExternalUrlSafeForNavigation(urlresult)) {
        urlresult = window.document.location.toString();
    }
    return urlresult;
}

function closePage() {
    "use strict";
    window.close();
}

function makeReportURL() {
    "use strict";
    window.external.msReportSafeUrl();
}

function threats() {
    "use strict";
    var threats = '0';

    var DocQuery = document.location.search;
    var BeginThreats = DocQuery.indexOf("Threats=");

    if (BeginThreats > 0) {
        BeginThreats += 8;
        var EndThreats = DocQuery.indexOf("&", BeginThreats);

        if (EndThreats > 0) {
            threats = DocQuery.substring(BeginThreats, EndThreats);
        } else {
            threats = DocQuery.substring(BeginThreats);
        }
    }

    return threats;
}

function contentLocations() {
    "use strict";
    var hostname = '0';

    var DocQuery = document.location.search;
    var BeginHostname = DocQuery.indexOf("Host=");

    if (BeginHostname > 0) {
        BeginHostname += 5;
        var EndHostname = DocQuery.indexOf("&", BeginHostname);

        if (EndHostname > 0) {
            hostname = DocQuery.substring(BeginHostname, EndHostname);
        } else {
            hostname = DocQuery.substring(BeginHostname);
        }
    }

    //some changes if we are reporting third-party content
    if (DocQuery.indexOf("BlockedDomain=") > 0) {
        sMainTitle = L_ContentUnsafe_TEXT;
        sOriginalSite = L_Content_TEXT + hostname;
        return blockedDomain();
    }

    return hostname;
}


//called if the blocked url isn't the top frame, ie. if the malicious content isn't top-level
function blockedDomain() {
    "use strict";
    var blockedName = "0";
    var DocQuery = document.location.search;
    var BeginBlockedName = DocQuery.indexOf("BlockedDomain=");

    if (BeginBlockedName > 0) {
        BeginBlockedName += 14;
        var EndBlockedName = DocQuery.indexOf("&", BeginBlockedName);

        if (EndBlockedName > 0) {
            blockedName = DocQuery.substring(BeginBlockedName, EndBlockedName);
        } else {
            blockedName = DocQuery.substring(BeginBlockedName);
        }
    }
    return blockedName;
}

function blockOverride() {
    "use strict";
    var blockOverride = '0';

    var DocQuery = document.location.search;
    var BeginBlock = DocQuery.indexOf("Block=");

    if (BeginBlock > 0) {
        BeginBlock += 6;
        var EndBlock = DocQuery.indexOf("&", BeginBlock);

        if (EndBlock > 0) {
            blockOverride = DocQuery.substring(BeginBlock, EndBlock);
        } else {
            blockOverride = DocQuery.substring(BeginBlock);
        }
    }

    return blockOverride;
}

function BodyLoad() {
    "use strict";
    // Display "More information" sections based on the reported threats:
    var iThreats = threats();

    // list of threat types:

    // UrlReputationThreats: URL_REPUTATION_PHISHING_BLOCK = 0x004
    var iPhishing = 4;

    // UrlReputationThreats: URL_REPUTATION_MALWARE_BLOCK = 0x010
    var iMalware = 16;

    // UrlReputationThreats: URL_REPUTATION_PUAA_BLOCK = 0x200
    var iUnwanted = 512;
    var overridden = false;

    if (iThreats & iPhishing) {
        document.getElementById("PhishingThreat").style.display = "list-item";
        document.getElementById("PhishingThreat").innerText = L_PhishingThreat_TEXT;
        overridden = true;
    }

    if (iThreats & iMalware) {
        document.getElementById("MalwareThreat").style.display = "list-item";
        document.getElementById("MalwareThreat").innerText = L_MalwareThreat_TEXT;
        overridden = true;
    }
    
    if (!overridden && (iThreats & iUnwanted)){
        sMainTitle = L_TopFrameUnwanted_TEXT;
        document.title = L_PUAATitle_TEXT;
        
        // Display/hide elements
        document.getElementById("recommendation").style.display = "none";
        document.getElementById("puaaRecommendation").style.display = "block";
        document.getElementById("moreInfoDropdown").style.display = "none";
        document.getElementById("actionsListPuaa").style.display = "block";
        document.getElementById("errorIcon").style.display = "none";
        document.getElementById("homepageButton").style.display = "none";
        
        // Change background colors
        document.getElementById("background").setAttribute("class", "black");
        document.getElementById("msgBackground").setAttribute("class", "msgBlock black");
        document.getElementById("msgBody").setAttribute("class", "black");
        
        // Change main title to red font
        document.getElementById("mainTitle").setAttribute("class", "redFont");
        
        // Change text color of body elements
        document.getElementById("contentlocations").style.color = "#575757";
        document.getElementById("hostsite").style.color = "#575757";
        document.getElementById("puaaRecommendation").style.color = "#575757";
    }

    // Display the override link if it is not blocked:
    var iBlockOverride = blockOverride();

    if (iBlockOverride == 0) {
        document.getElementById("DoOverride").style.display = "block";
        document.getElementById("overrideLink").href = sRealPageUrl;
        if (!overridden && (iThreats & iUnwanted)){
            document.getElementById("DoOverridePuaa").style.display = "block";
            document.getElementById("overrideLinkPuaa").href = sRealPageUrl;
        }
    } else {
        document.getElementById("DoOverride").style.display = "none";
        if (!overridden && (iThreats & iUnwanted)){
            document.getElementById("DoOverridePuaa").style.display = "none";
        }
    }

    document.getElementById("contentlocations").innerText = sContentLocations;
    if (sOriginalSite) {
        document.getElementById("hostsite").innerText = sOriginalSite;
    }
    document.getElementById("mainTitle").innerText = sMainTitle;

    // Manually remove <noscript> elements for accessibility purposes
    removeNoScriptElements();

    reverseForRTL(iThreats & iUnwanted);

    document.getElementById("moreInformationDropdownLink").setAttribute("aria-label", L_MOREINFO_TEXT);
    document.getElementById("moreInformationDropdownSpan").innerText = L_MOREINFO_TEXT;
    
}

function reverseForRTL(isPua) {
    "use strict";
    if (document.dir == "rtl") {
        document.getElementById("threatsList").className = "ul-rtl";
        document.getElementById("PhishingThreat").className = "bullet-li-rtl";
        document.getElementById("MalwareThreat").className = "bullet-li-rtl";
        document.getElementById("actionsList").className = "ul-rtl";
        document.getElementById("DoReportSafe").className = "caret-li-rtl";
        document.getElementById("DoOverride").className = "caret-li-rtl";
        if (isPua){
            document.getElementById("actionsListPuaa").className = "ul-rtl";
            document.getElementById("DoReportSafePuaa").className = "caret-li-rtl";
            document.getElementById("DoOverridePuaa").className = "caret-li-rtl";
        }
        document.getElementById("branding").style.textAlign = "left";
    }
}

function expandCollapseIM(elem) {
    "use strict";
    if (document.getElementById) {
        var ecBlock = document.getElementById(elem);

        if (ecBlock !== null) {
            if (ecBlock.currentStyle.display === "block") {
                // hide info
                ecBlock.style.display = "none";
            } else {
                // shows the info.
                ecBlock.style.display = "block";
            }
        }
    }
}
