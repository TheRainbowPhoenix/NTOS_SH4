var resourceJSON = "";

function getUrl() {
    "use strict";
    // In real bits, urls get returned to our script like this:
    // ms-appx-web://microsoft.microsoftedge/assets/errorpages/dnserror.html#http://www.docUrl.com/bar.htm
    // For testing set docUrl = "ms-appx-web://microsoft.microsoftedge/assets/errorpages/dnserror.html#https://www.microsoft.com/bar.htm"

    var docUrl = document.location.href;

    // Get location of start of url after the #
    var beginIndex = docUrl.indexOf('#') + 1;

    var urlResult;
    // For file:// urls, show the entire url.  Otherwise, restrict to the domain.
    if (docUrl.indexOf("file://", beginIndex) == -1) {
        // Looking for the :// after the protocol but skipping the ms-appx-web://
        var protocolEndIndex = docUrl.indexOf("://", beginIndex);

        // This finds the ending slash for the domain server
        var endIndex = docUrl.indexOf("/", protocolEndIndex + 3);
        urlResult = docUrl.substring(beginIndex, endIndex);
    }
    else {
        urlResult = docUrl.substring(beginIndex);
    }

    return urlResult
}

function isExternalUrlSafeForNavigation(urlStr) {
    "use strict";
    var regEx = new RegExp("^(http(s?)|ftp|file)://", "i");
    return regEx.exec(urlStr);
}

function clickRefresh() {
    "use strict";
    var currentLocation = document.location.href;
    var poundIndex = currentLocation.indexOf('#');

    if (poundIndex != -1 && poundIndex + 1 < currentLocation.length && isExternalUrlSafeForNavigation(currentLocation.substring(poundIndex + 1))) {
        window.location.replace(currentLocation.substring(poundIndex + 1));
    }
}

function clickSearch() {
    "use strict";
    var currentLocation = document.location.href;
    var poundIndex = currentLocation.indexOf('#');

    if (poundIndex != -1 && poundIndex + 1 < currentLocation.length && isExternalUrlSafeForNavigation(currentLocation.substring(poundIndex + 1))) {
        window.open('https://www.bing.com/search?q=' + currentLocation.substring(poundIndex + 1));
    }
}

function getNavigationURL() {
    "use strict";
    var currentLocation = document.location.href;
    var poundIndex = currentLocation.indexOf('#');
    var possibleNavigationURL = currentLocation.substring(poundIndex + 1);

    if (poundIndex != -1 && poundIndex + 1 < currentLocation.length && isExternalUrlSafeForNavigation(possibleNavigationURL)) {
        return possibleNavigationURL;
    } else {
        return '';
    }
}

function isMergedErrorFile() {
    "use strict";
    var url = document.location.href.toLowerCase();
    
    var localAnchor = url.indexOf("#");
    url = url.substring(0, (localAnchor == -1) ? url.length : localAnchor);

    var query = url.indexOf("?");
    url = url.substring(0, (query == -1) ? url.length : query);

    return url.indexOf("errorpages.html", url.lastIndexOf("/") + 1) >= 0;
}

function getErrorCodeFromQuery() {
    "use strict";
    var errorCode = '';
    var errorQueryKey = "error=";

    var query = document.location.search;
    var errorQueryStart = query.indexOf(errorQueryKey);
    if (errorQueryStart > 0) {
        var ampersandStart = query.indexOf("&", errorQueryStart);
        if (ampersandStart > 0) {
            errorCode = query.substring(errorQueryStart + errorQueryKey.length, ampersandStart);
        } else {
            errorCode = query.substring(errorQueryStart + errorQueryKey.length);
        }
    }

    return errorCode;
}

function showErrorPage() {
    "use strict";
    if (isMergedErrorFile()) {
        setWebpageUrl();

        var errorCode = getErrorCodeFromQuery();
        setDocumentTitle(errorCode);
        initializeErrorCodeDiv(errorCode);
        initializeContinueLink(errorCode);

        // Show the div for this error code.
        document.getElementById(errorCode).style.display = "inline";
    }
}

function goToLocalizedErrorPage() {
    "use strict";
     showErrorPage();
}

function setWebpageUrl() {
    "use strict";
    var url = getUrl();
    var urlElements = document.getElementsByClassName("webpageURL");
    for (var i = 0; i < urlElements.length; i++) {
        urlElements[i].textContent = url;
    }
}

function setDocumentTitle(errorCode) {
    "use strict";
    // 1, 2 Set via initializeDnsError.
    if (errorCode == 3) { document.title = L_Syntax_Title_TEXT; }
    else if (errorCode == 4) { document.title = L_NavCancel_Title_TEXT; }
    else if (errorCode == 5) { document.title = L_PhishingSite_Title_TEXT; }
    else if (errorCode == 6) { document.title = L_InvalidCert_Title_TEXT; }
    else if (errorCode == 7) { document.title = L_SSLNavCancel_Title_TEXT; }
    else if (errorCode == 8) { document.title = L_UnknownProtocol_Title_TEXT; }
    else if (errorCode == 9) { document.title = L_ForbidFraming_Title_TEXT; }
    else if (errorCode == 10) { document.title = L_ProxyError_Title_TEXT; }
    // ERRORPAGE_EVSITE is legacy only
    else if (errorCode == 12) { document.title = L_TLSError_Title_TEXT; }
    // ERRORPAGE_BLOCKSITE is legacy only
    else if (errorCode == 14) { document.title = L_HSTS_Title_TEXT; }
    // ERRORPAGE_INSECURESSL3FALLBACK is legacy only
    // ERRORPAGE_SSL3FALLBACKNAVCANCEL is legacy only
    else if (errorCode == 17) { document.title = L_PDF_Title_TEXT; }
    else if (errorCode == 18) { document.title = L_PDF_Title_TEXT; }
    else if (errorCode == 400) { document.title = L_Http_400_Title_TEXT; }
    else if (errorCode == 403) { document.title = L_Http_403_Title_TEXT; }
    else if (errorCode == 404) { document.title = L_Http_404_Title_TEXT; }
    else if (errorCode == 405) { document.title = L_Http_405_Title_TEXT; }
    else if (errorCode == 406) { document.title = L_Http_406_Title_TEXT; }
    else if (errorCode == 408) { document.title = L_Http_408_409_Title_TEXT; }
    else if (errorCode == 409) { document.title = L_Http_408_409_Title_TEXT; }
    else if (errorCode == 410) { document.title = L_Http_410_Title_TEXT; }
    else if (errorCode == 500) { document.title = L_Http_500_Title_TEXT; }
    else if (errorCode == 501) { document.title = L_Http_501_Title_TEXT; }
    else if (errorCode == 505) { document.title = L_Http_501_Title_TEXT; }
    else if (errorCode == 100004) { document.title = L_WPC_Title_TEXT; }
    else if (errorCode == 100005) { document.title = L_Disable_About_Flag_Title_TEXT; }
}

function initializeErrorCodeDiv(errorCode) {
    "use strict";
    if (errorCode == 1 || errorCode == 2) {
        // ERRORPAGE_DNS || ERRORPAGE_DNS_DIAGOFF
        initializeDnsError();
    }
    else if (errorCode == 100004) {
        handleWpcBlockedFrame();
    }
}

function initializeContinueLink(errorCode) {
    "use strict";
    if (errorCode == 6) {
        document.getElementById('continueLink').href = getNavigationURL();
    }
}

function initializeDnsError() {
    "use strict";
    // First check if the user is connected to the internet.
    checkConnectionForDnsError();

    // Attach an event to detect changes in network connectivity.
    if (document.addEventListener) {
        addEventListener("offline", reportConnectionEvent, false);
    }
    else {
        attachEvent("onoffline", reportConnectionEvent);
    }

    // Set events to fire.
    document.body.ononline = reportConnectionEvent;
    document.body.onoffline = reportConnectionEvent;
}

function checkConnectionForDnsError() {
    "use strict";
    var notConnected = document.getElementById("NotConnected");
    var pageUnavailable = document.getElementById("PageUnavailable");

    if (navigator.onLine) { // The network connection is connected.
        document.title = L_Unavailable_Title_TEXT;

        notConnected.style.display = "none";
        pageUnavailable.style.display = "";
    }
    else { // no internet
        document.title = L_Disconnected_Title_TEXT;

        notConnected.style.display = "";
        pageUnavailable.style.display = "none";
    }
}

function reportConnectionEvent(e) {
    "use strict";
    if (!e) e = window.event;

    if ('online' == e.type) {
        // Using a setTimeout to account for any lag between us getting the connected event and the machine obtaining an IP.
        setTimeout("clickRefresh()", 1000);
    }
    else {
        checkConnectionForDnsError();
    }
}

// This function determines the block page URL for pages blocked by parental controls.
function getWpcBlockPageURL() {
    "use strict";

    var params = document.location.search;
    var server = "origin.sdx.microsoft.com";

    var errorParam = "error=100004&"
    var queryIdx = params.indexOf(errorParam);
    if (queryIdx != -1) {
        params = params.substring(queryIdx + errorParam.length);
    }

    var isIntEnv = "env=int&";
    var intIdx = params.indexOf(isIntEnv);
    if (intIdx != -1) {
        server = "sdx.microsoft-int.com";
        params = params.substring(intIdx + isIntEnv.length);
    }
    return 'https://' + server + '/family/restricted-web2?' + params;
}

// This function sets the URL for the "Ask for permission" button for pages blocked by parental controls.
function handleWpcBlockedFrame() {
    "use strict";
    var link = document.getElementById('wpcReqAcc');
    if (link) {
        link.href = getWpcBlockPageURL();
    }
}
