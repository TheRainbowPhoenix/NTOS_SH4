// This file contains some shared javascript functions for error pages. Javascript files cannot be localized via pri 
// resources. As such some of these functions use variables that are expected to be defined within the html file that
// includes this js file. The html file should define these only if it is calling the function that uses a given 
// variable. Below is the list of variables used in functions in this file:
//
//     L_GOBACK_TEXT
//     L_REFRESH_TEXT
//     L_MOREINFO_TEXT 
//     L_OFFLINE_USERS_TEXT
//     L_RELOAD_TEXT
//     L_HIDE_HOTKEYS_TEXT
//     L_SHOW_HOTKEYS_TEXT
//     L_CONNECTION_OFF_TEXT
//     L_CONNECTION_ON_TEXT
//     L_INTERNET_NOT_CONNECTED_TEXT
//     L_INTERNET_CONNECTED_TEXT
//     L_TLS_SSL_TEXT
//

function isExternalUrlSafeForNavigation(urlStr) {
    "use strict";
    var regEx = new RegExp("^(http(s?)|ftp|file)://", "i");
    return regEx.exec(urlStr);
}

function clickRefresh() {
    "use strict";
    var location = window.location.href;
    var poundIndex = location.indexOf('#');

    if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1))) {
        window.location.replace(location.substring(poundIndex+1));
    }
}

function navCancelInit() {
    "use strict";
    var location = window.location.href;
    var poundIndex = location.indexOf('#');

    if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1))) {
        var bElement = document.createElement("A");
        bElement.innerText = L_REFRESH_TEXT;
        bElement.href = 'javascript:clickRefresh()';
        navCancelContainer.appendChild(bElement);
    } else {
        var textNode = document.createTextNode(L_RELOAD_TEXT);
        navCancelContainer.appendChild(textNode);
    }
}

function getDisplayValue(elem) {
    "use strict";
    var objStyle;
    if (window.getComputedStyle) {
        objStyle = window.getComputedStyle(elem);
    } else {
        objStyle = elem.currentStyle;
    }
    return objStyle.display;
}

function expandCollapse(elem, changeImage) {
    "use strict";
    if (document.getElementById) {
        var ecBlock = document.getElementById(elem);

        if (ecBlock != null) {
            if (changeImage) {
                //gets the image associated
                elemImage = document.getElementById(elem + "Image");
            }

            //make sure elemImage is good
            if (!changeImage || (elemImage != null)) {
                var displayValue = getDisplayValue(ecBlock);
                if (displayValue == "none" || displayValue == null || displayValue == "") {
                    //shows the info.
                    ecBlock.style.display = "block";
                    if (changeImage) {
                        //Just got in expanded mode. Thus, change image to "collapse"
                        elemImage.src = "up.png";
                    }
                }
                else if (displayValue == "block") {
                    //hide info
                    ecBlock.style.display = "none";
                    if (changeImage) {
                        //Just got in collapsed mode. Thus, change image to "expand"
                        elemImage.src = "down.png";
                    }
                } else {
                    //catch any weird circumstances.
                    ecBlock.style.display = "block";
                    if (changeImage) {
                        elemImage.src = "up.png";
                    }
                }
            }//end check elemImage
        }//end check ecBlock
    }//end getElemById
}//end expandCollapse


function initHomepage() {
    "use strict";
    // in real bits, urls get returned to our script like this:
    // res://shdocvw.dll/http_404.htm#http://www.DocURL.com/bar.htm

    //For testing use
    //DocURL = "res://shdocvw.dll/http_404.htm#http://www.microsoft.com/bar.htm"
    var DocURL = document.location.href;

    var poundIndex = DocURL.indexOf('#');

    if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1))) {

       //this is where the http or https will be, as found by searching for :// but skipping the res://
       var protocolIndex = DocURL.indexOf("://", 4);

       //this finds the ending slash for the domain server
       var serverIndex = DocURL.indexOf("/", protocolIndex + 3);

       //for the href, we need a valid URL to the domain. We search for the # symbol to find the begining
       //of the true URL, and add 1 to skip it - this is the BeginURL value. We use serverIndex as the end marker.
       //urlresult=DocURL.substring(protocolIndex - 4,serverIndex);
       var BeginURL = DocURL.indexOf("#",1) + 1;
       var urlresult = DocURL.substring(BeginURL, serverIndex);
       if (protocolIndex - BeginURL > 7)
           urlresult="";

        //for display, we need to skip after http://, and go to the next slash
       var displayresult = DocURL.substring(protocolIndex + 3, serverIndex);
    } else {
       var displayresult = "";
       var urlresult = "";
    }

    var aElement = document.createElement("A");

    aElement.innerText = displayresult;
    aElement.href = urlresult;

    homepageContainer.appendChild(aElement);
}


function initConnectionStatus() {
    "use strict";
    if (navigator.onLine) { //the network connection is connected
        checkConnection.innerText = L_CONNECTION_ON_TEXT;
    } else {
        checkConnection.innerText = L_CONNECTION_OFF_TEXT;
    }
}

function initGoBack() {
    "use strict";
    //fills in the span container for "back to previous page"
    //Basically, makes "back to previous page" a clickable item IF there's something in the navstack.

    if (history.length < 1) {
        //this page is the only thing. Nothing in history.
        var textNode = document.createTextNode(L_GOBACK_TEXT);
        goBackContainer.appendChild(textNode);
    } else {
        var bElement = document.createElement("A");
        bElement.innerText = L_GOBACK_TEXT ;
        bElement.href = "javascript:history.back();";
        goBackContainer.appendChild(bElement);
    }
}

function initMoreInfo(infoBlockID) {
    "use strict";
    var bElement = document.createElement("A");
    bElement.innerText = L_MOREINFO_TEXT;
    bElement.href = "javascript:expandCollapse(\'infoBlockID\', true);";
    moreInfoContainer.appendChild(bElement);

}

function initOfflineUser(offlineUserID) {
    "use strict";
    var bElement = document.createElement("A");
    bElement.innerText = L_OFFLINE_USERS_TEXT;
    bElement.href = "javascript:expandCollapse('offlineUserID', true);";
    offlineUserContainer.appendChild(bElement);
}

function initUnframeContent() {
    "use strict";
    var location = window.location.href;
    var poundIndex = location.indexOf('#');

    if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1))) {
        document.getElementById("whatToDoIntro").style.display="";
        document.getElementById("whatToDoBody").style.display="";
    }
}

function removeNoScriptElements() {
    "use strict";
    var noScriptElements = document.getElementsByTagName("noscript");
    for (var i = noScriptElements.length - 1; i >= 0; i--) {
        var bElement = noScriptElements[i];
        if (bElement !== null) {
            bElement.parentNode.removeChild(bElement);
        }
    }
}

function makeNewWindow() {
    "use strict";
    var location = window.location.href;
    var poundIndex = location.indexOf('#');

    if (poundIndex != -1 && poundIndex+1 < location.length && isExternalUrlSafeForNavigation(location.substring(poundIndex+1))) {
        window.open(location.substring(poundIndex+1));
    }
}

function setTabInfo(tabInfoBlockID) {
    "use strict";
    //removes the previous tabInfo text
    var bPrevElement = document.getElementById("tabInfoTextID");
    var bPrevImage   = document.getElementById("tabInfoBlockIDImage");

    if (bPrevElement != null) {
        tabInfoContainer.removeChild(bPrevElement);
    }

    if (bPrevImage != null) {
        tabImageContainer.removeChild(bPrevImage);
    }

    var bElement = document.createElement("A");
    var bImageElement = document.createElement("IMG");

    var ecBlock = document.getElementById(tabInfoBlockID);

    //determines if the block is closed
    if ((ecBlock != null) &&
        (getDisplayValue(ecBlock) == "none" || getDisplayValue(ecBlock) == null || getDisplayValue(ecBlock) == "")) {
        bElement.innerText = L_SHOW_HOTKEYS_TEXT;
        bImageElement.alt = L_SHOW_HOTKEYS_TEXT;
        bImageElement.src="down.png";
    } else {
        bElement.innerText = L_HIDE_HOTKEYS_TEXT;
        bImageElement.alt = L_HIDE_HOTKEYS_TEXT;
        bImageElement.src="up.png";
    }

    bElement.id = "tabInfoTextID";
    bElement.href = "javascript:expandCollapse(\'tabInfoBlockID\', false); setTabInfo('tabInfoBlockID');";


    bImageElement.id="tabInfoBlockIDImage";
    bImageElement.border="0";
    bImageElement.className="actionIcon";

    tabInfoContainer.appendChild(bElement);
    tabImageContainer.appendChild(bImageElement);
}

function launchInternetOptions() {
    "use strict";
    window.external.msLaunchInternetOptions();
}

function diagnoseConnection() {
    "use strict";
    window.external.DiagnoseConnection();
}

function diagnoseConnectionAndRefresh() {
    "use strict";
    window.external.DiagnoseConnection();
    if (navigator.onLine) { //network connection is connected
        clickRefresh();
    }
}

function getInfo() {
    "use strict";
    //first check if user is connected to the internet
    checkConnection();

    //attach an event to detect changes in network connectivity
    if (document.addEventListener) {
        addEventListener("offline", reportConnectionEvent, false);
    } else {
        attachEvent("onoffline", reportConnectionEvent);
    }

    //set events to fire
    document.body.ononline = reportConnectionEvent;
    document.body.onoffline = reportConnectionEvent;
}

function checkConnection() {
    "use strict";
    var newHeading = document.getElementById("mainTitle");
    var notConnectedTasks = document.getElementById("notConnectedTasks");
    var cantDisplayTasks = document.getElementById("cantDisplayTasks");

    if (navigator.onLine) { //the network connection is connected
        document.title = L_INTERNET_CONNECTED_TEXT;
        newHeading.textContent = L_INTERNET_CONNECTED_TEXT;

        addURL();

        notConnectedTasks.style.display = "none";
        cantDisplayTasks.style.display = "";
    } else {
        document.title = L_INTERNET_NOT_CONNECTED_TEXT;
        newHeading.textContent = L_INTERNET_NOT_CONNECTED_TEXT;

        notConnectedTasks.style.display = "";
        cantDisplayTasks.style.display = "none";
    }
 }

function reportConnectionEvent(e) {
    "use strict";
    if (!e) e = window.event;

    if ('online' == e.type) {
        setTimeout ( "clickRefresh()", 1000 ); //using a setTimeout to account for any lag between us getting the connected event and the machine obtaining an IP
    }
    else if ('offline' == e.type) {
        checkConnection();
    } else {
        checkConnection();
    }
}

function addURL() {
    "use strict";
    //in real bits, urls get returned to our script like this:
    //res://shdocvw.dll/http_404.htm#http://www.DocURL.com/bar.htm
    //For testing set DocURL = "res://shdocvw.dll/http_404.htm#https://www.microsoft.com/bar.htm"
    var urlResult = "";
    var DocURL = document.location.href;
    var urlPlaceholder = document.getElementById("webpage");

    var beginIndex = DocURL.indexOf('#') + 1;

    //only show URLs that are not file:/// urls. file:// urls are returned to us as "res://shdocvw.dll/http_404.htm#file:///C:/test/test.htm" for local files and as "res://shdocvw.dll/http_404.htm#file://foo/test.htm" for UNC shares
    if (DocURL.indexOf("file://", beginIndex) == -1) {
        //looking for the :// after the protocol but skipping the res://
        var protocolEndIndex = DocURL.indexOf("://", beginIndex);

        //this finds the ending slash for the domain server
        var endIndex=DocURL.indexOf("/", protocolEndIndex + 3);

        urlResult = DocURL.substring(beginIndex, endIndex);
    }
    //add a space in the end for the display
    urlPlaceholder.innerText = urlResult + " ";
}

function addDomainName() {
    "use strict";
    var domainNamePlaceholder = document.getElementById("DomainName");

    //add a space in the end for the display
    domainNamePlaceholder.innerText = findValue("DomainName=") + " ";
}

function addProxyDetail() {
    "use strict";
    var proxyDetailPlaceholder = document.getElementById("ProxyDetail");

    proxyDetailPlaceholder.innerText = findValue("ProxyDetail=");
}

function findValue(key) {
    "use strict";
    var value = '';

    DocQuery = document.location.search;
    BeginString = DocQuery.indexOf(key);

    if (BeginString > 0) {
        BeginString += key.length;
        EndString = Math.max(0, Math.min(DocQuery.indexOf("&", BeginString), DocQuery.indexOf("#", BeginString)));

        if (EndString > 0) {
            value = DocQuery.substring(BeginString, EndString);
        } else {
            value = DocQuery.substring(BeginString);
        }
    }

    return value;
}

function isHTTPS(cantDisplayTasks) {
    "use strict";
    //in real bits, urls get returned to our script like this:
    //res://shdocvw.dll/http_404.htm#http://www.DocURL.com/bar.htm

    //For testing set DocURL = "res://shdocvw.dll/http_404.htm#https://www.microsoft.com/bar.htm"
    var DocURL = document.location.href;
    var poundIndex = DocURL.indexOf('#');

    //this is where the http or https will be, as found by searching for :// but skipping the res:// and going after the #
    var protocolIndex = DocURL.indexOf("https://", poundIndex);

    if (protocolIndex>poundIndex) {
        var bElement = document.createElement("li");
        bElement.textContent = L_TLS_SSL_TEXT;
        cantDisplayTasks.appendChild(bElement);
    }
}